'use strict'

module.exports = (str, from, to) => str.replace(from, to)
