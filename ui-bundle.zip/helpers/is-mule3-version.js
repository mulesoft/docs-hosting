'use strict'

module.exports = (version) => version.startsWith('0.')
