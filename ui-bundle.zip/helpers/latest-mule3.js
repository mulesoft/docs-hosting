'use strict'

module.exports = (versions) => versions.find((it) => it.version.startsWith('0.'))
