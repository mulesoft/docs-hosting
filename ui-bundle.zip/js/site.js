;(function () {
  'use strict'

  function buildNav (nav, data, page, path) {
    var navList = document.createElement('ol')
    navList.className = 'nav-list'
    var chevron = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
    chevron.setAttribute('class', 'svg') // className property is read-only on an SVG
    chevron.setAttribute('viewBox', '0 0 30 30')
    chevron.setAttribute('width', '30')
    chevron.setAttribute('height', '30')
    var svgPath = document.createElementNS(chevron.namespaceURI, 'path')
    svgPath.setAttribute(
      'd',
      'M15.003 21.284L6.563 9.232l1.928-.516 6.512 9.299 6.506-9.299 1.928.516-8.434 12.052z'
    )
    chevron.appendChild(svgPath)
    var pageNavItem
    var connectorNavItems = []
    var connectorsNavItem
    var rtfcloudNavItem
    var rtfcloudNavItems = []
    data.splice(0, data.length).forEach(function (product) {
      var productName = product.name
      var productForPage = productName === page.product
      var connector = isConnector(productName)
      var rtfcloud = isRTFCloud(productName)
      var navItem = document.createElement('li')
      var active
      if (productForPage) {
        pageNavItem = navItem
        if (!path.active.length && product.url === page.url) {
          active = true
          path.active.push(navItem)
        }
      }
      if (productName === 'connectors') {
        connectorsNavItem = navItem
        if (isConnector(page.product)) active = true
      } else if (connector) {
        connectorNavItems.push(navItem)
      }
      if (productName === 'rtfcloud') {
        rtfcloudNavItem = navItem
        if (isRTFCloud(page.product)) active = true
      } else if (rtfcloud) {
        rtfcloudNavItems.push(navItem)
      }
      navItem.className = active ? 'nav-li active' : 'nav-li'
      if (connector || rtfcloud) {
        navItem.dataset.depth = 1
      } else {
        navItem.dataset.depth = 0
      }
      navItem.dataset.product = productName
      var productHeading = document.createElement('div')
      productHeading.className = 'flex align-center justify-justified'
      var productLink = document.createElement('a')
      productLink.className = 'flex grow strong link nav-link nav-heading'
      var productIcon = document.createElement('img')
      productIcon.className = 'icon no-pointer'
      var iconName
      if (connector) {
        iconName = 'connectors'
      } else if (rtfcloud) {
        iconName = 'rtfcloud'
      } else {
        iconName = productName
      }
      productIcon.src =
        page.uiRootPath +
        '/img/icons/' + iconName + '.svg'
      productLink.appendChild(productIcon)
      productLink.appendChild(document.createTextNode(' ' + product.title))
      productHeading.appendChild(productLink)
      if (product.versions.length > 1) {
        var latestVersion = product.versions[0]
        var currentVersion =
          latestVersion.displayVersion || latestVersion.version
        var versionButton = document.createElement('button')
        versionButton.className = 'flex align-center shrink button versions'
        versionButton.dataset.product = productName
        var versionLabel = document.createElement('span')
        versionLabel.className = 'version-label'
        versionLabel.appendChild(document.createTextNode(currentVersion))
        versionButton.appendChild(versionLabel)
        versionButton.appendChild(document.createTextNode(' '))
        versionButton.appendChild(chevron.cloneNode(true))
        var versionMenu = document.createElement('div')
        versionMenu.className = 'popover version-popover'
        var currentVersionList = document.createElement('ol')
        currentVersionList.className = 'ol'
        var currentVersionHeading = document.createElement('li')
        currentVersionHeading.className = 'li-heading'
        currentVersionHeading.appendChild(
          document.createTextNode('Current version')
        )
        currentVersionList.appendChild(currentVersionHeading)
        var currentVersionItem = document.createElement('li')
        currentVersionItem.className =
          'flex align-center justify-justified li version'
        currentVersionItem.dataset.product = productName
        currentVersionItem.dataset.version = currentVersion
        currentVersionItem.appendChild(document.createTextNode(currentVersion))
        currentVersionList.appendChild(currentVersionItem)
        versionMenu.appendChild(currentVersionList)
        var previousVersionsList = document.createElement('ol')
        var previousVersionsHeading = document.createElement('li')
        previousVersionsHeading.className = 'li-heading'
        previousVersionsHeading.appendChild(
          document.createTextNode('Previous versions')
        )
        previousVersionsList.appendChild(previousVersionsHeading)
        product.versions.slice(1).forEach(function (version) {
          var previousVersionItem = document.createElement('li')
          previousVersionItem.className =
            'flex align-center justify-justified li version'
          previousVersionItem.dataset.product = productName
          previousVersionItem.dataset.version =
            version.displayVersion || version.version
          previousVersionItem.appendChild(
            document.createTextNode(previousVersionItem.dataset.version)
          )
          previousVersionsList.appendChild(previousVersionItem)
        })
        versionMenu.appendChild(previousVersionsList)
        versionButton.appendChild(versionMenu)
        productHeading.appendChild(versionButton)
        setPinnedVersion(versionButton, { product: productName }, navItem)
        if (productForPage) {
          initVersionSelector(versionButton, versionMenu)
        } else {
          var buildNavForProductAndInitVersionSelector = function () {
            versionButton.removeEventListener(
              'click',
              buildNavForProductAndInitVersionSelector
            )
            versionButton.removeEventListener(
              'touchend',
              buildNavForProductAndInitVersionSelector
            )
            buildNavForProduct(nav, navItem, product, page)
            initVersionSelector(versionButton, versionMenu, true)
          }
          versionButton.addEventListener(
            'click',
            buildNavForProductAndInitVersionSelector
          )
          versionButton.addEventListener(
            'touchend',
            buildNavForProductAndInitVersionSelector
          )
        }
      }
      navItem.appendChild(productHeading)
      if (productForPage) {
        productLink.addEventListener('click', toggleNav)
        productLink.addEventListener('touchend', toggleNav)
        buildNavForProduct(nav, navItem, product, page, {
          active: path.active,
          current: [navItem],
        })
      } else {
        var buildNavForProductAndToggle = function (e) {
          productLink.removeEventListener('click', buildNavForProductAndToggle)
          productLink.removeEventListener(
            'touchend',
            buildNavForProductAndToggle
          )
          buildNavForProduct(nav, navItem, product, page)
          toggleNav(e)
          productLink.addEventListener('click', toggleNav)
          productLink.addEventListener('touchend', toggleNav)
        }
        productLink.addEventListener('click', buildNavForProductAndToggle)
        productLink.addEventListener('touchend', buildNavForProductAndToggle)
      }
      navList.appendChild(navItem)
    })
    if (connectorsNavItem && connectorNavItems.length) {
      var connectorsNavList = connectorsNavItem.querySelector(
        'ol[data-product]'
      )
      if (!connectorsNavList) {
        connectorsNavList = document.createElement('ol')
        connectorsNavList.classList = 'nav-list parent'
        if (!isConnector(page.product)) { connectorsNavList.style.display = 'none' }
        connectorsNavList.dataset.product = 'connectors'
        connectorsNavList.dataset.version = 'master'
        connectorsNavItem.append(connectorsNavList)
      }
      connectorNavItems.forEach(function (navItem) {
        connectorsNavList.appendChild(navItem)
      })
      connectorNavItems.length = 0
    }
    if (rtfcloudNavItem && rtfcloudNavItems.length) {
      var rtfcloudNavList = rtfcloudNavItem.querySelector(
        'ol[data-product]'
      )
      if (!rtfcloudNavList) {
        rtfcloudNavList = document.createElement('ol')
        rtfcloudNavList.classList = 'nav-list parent'
        if (!isRTFCloud(page.product)) { rtfcloudNavList.style.display = 'none' }
        rtfcloudNavList.dataset.product = 'rtfcloud'
        rtfcloudNavList.dataset.version = 'master'
        rtfcloudNavItem.append(rtfcloudNavList)
      }
      rtfcloudNavItems.forEach(function (navItem) {
        rtfcloudNavList.appendChild(navItem)
      })
      rtfcloudNavItems.length = 0
    }
    // @TODO - do I need this and line 188
    nav.appendChild(navList)
    // NOTE we could mark active when navigation is built if we appended children to parent eagerly
    if (path.active.length) {
      path.active.forEach(function (it) {
        it.classList.add('active')
        if (it.parentNode.classList.contains('parent')) { it.parentNode.style.display = '' }
      })
    } else if (pageNavItem) {
      pageNavItem.classList.add('active')
    } else {
      var notice = document.createElement('div')
      notice.className = 'nav-list nav-heading'
      notice.appendChild(
        document.createTextNode('Site navigation data not found.')
      )
      nav.replaceChild(notice, navList)
    }
  }

  function buildNavForProduct (nav, navItem, product, page, path) {
    if (navItem.classList.contains('is-loaded')) return
    navItem.classList.add('is-loaded')
    product.versions.forEach(function (version) {
      var items = ((version.sets || [])[0] || {}).items || [] // only consider items in first menu
      if (items.length) {
        buildNavTree(
          nav,
          navItem,
          product.name,
          version.displayVersion || version.version,
          items,
          1,
          page,
          path
        )
      }
    })
  }

  function buildNavTree (
    nav,
    parent,
    productName,
    version,
    items,
    level,
    page,
    path
  ) {
    var existingItems = []
    var navList
    if (
      productName === 'connectors' &&
      version === 'master' &&
      level === 1 &&
      (navList = parent.querySelector('ol[data-product]'))
    ) {
      for (var i = 0, len = navList.children.length; i < len; i++) {
        var navListChild = navList.removeChild(navList.firstChild)
        if (navListChild.tagName === 'LI') existingItems[i] = navListChild
      }
      parent.removeChild(navList)
    } else if (
      productName === 'rtfcloud' &&
      version === 'master' &&
      level === 1 &&
      (navList = parent.querySelector('ol[data-product]'))
    ) {
      for (var j = 0, length = navList.children.length; j < length; j++) {
        var rtfcloudNavListChild = navList.removeChild(navList.firstChild)
        if (rtfcloudNavListChild.tagName === 'LI') existingItems[j] = rtfcloudNavListChild
      }
      parent.removeChild(navList)
    } else {
      navList = document.createElement('ol')
      navList.className = 'nav-list parent'
      if (level === 1) {
        if (!(productName === page.product && version === page.version)) { navList.style.display = 'none' }
        navList.dataset.product = productName
        navList.dataset.version = version
      } else if (!parent.classList.contains('active')) {
        navList.style.display = 'none'
      }
    }
    items.forEach(function (item) {
      var navItem = document.createElement('li')
      var active
      if (path && !path.active.length) {
        if (
          item.url === page.url &&
          productName === page.product &&
          version === page.version &&
          (active = true)
        ) {
          path.current.concat(navItem).forEach(function (activeItem) {
            path.active.push(activeItem)
          })
        }
      }
      navItem.className = active ? 'nav-li active' : 'nav-li'
      navItem.dataset.depth = level + ((isConnector(productName) || isRTFCloud(productName)) ? 1 : 0)
      if (item.items) {
        var navToggle = document.createElement('button')
        navToggle.className = 'subnav-toggle'
        navItem.appendChild(navToggle)
        navToggle.addEventListener('click', toggleSubnav)
        navToggle.addEventListener('touchend', toggleSubnav)
      }
      if (item.url) {
        var navLink = document.createElement('a')
        navLink.className =
          'flex shrink align-center link nav-link' +
          (active ? ' active' : '') +
          (item.items ? ' nav-nested' : '')
        if (item.urlType === 'external') {
          navLink.href = item.url
          navLink.target = '_blank'
        } else {
          navLink.href = relativize(page.url, item.url)
        }
        navLink.innerHTML = item.content
        navItem.appendChild(navLink)
      } else {
        var navHeading = document.createElement('span')
        navHeading.className =
          'flex grow align-center nav-heading' +
          (item.items ? ' nav-nested' : '')
        var navHeadingSpan = document.createElement('span')
        navHeadingSpan.className = 'span'
        navHeadingSpan.innerHTML = item.content
        navHeading.appendChild(navHeadingSpan)
        navItem.appendChild(navHeading)
      }
      if (item.items) {
        var nestedPath = path && {
          active: path.active,
          current: path.current.concat(navItem),
        }
        buildNavTree(
          nav,
          navItem,
          productName,
          version,
          item.items,
          level + 1,
          page,
          nestedPath
        )
      }
      navList.appendChild(navItem)
    })
    if (existingItems.length) {
      existingItems.forEach(function (navItem) {
        navList.appendChild(navItem)
      })
    }
    return parent.appendChild(navList)
  }

  function toggleNav (e, selected, nav) {
    var navItem, navList, navListQuery
    if (!e) {
      // on page load (when navigating from the location bar)
      if (selected) {
        navListQuery = '.nav-list[data-product="' + selected.product + '"]'
        var productVersionSelector = nav.querySelector(
          'button[data-product="' + selected.product + '"]'
        )
        if (productVersionSelector) {
          setPinnedVersion(productVersionSelector, selected)
          navListQuery += '[data-version="' + selected.version + '"]'
        }
        if ((navList = nav.querySelector(navListQuery))) {
          scrollToActive(nav, navList)
          window.addEventListener('load', function scrollToActiveOnLoad () {
            window.removeEventListener('load', scrollToActiveOnLoad)
            scrollToActive(nav, navList) // scroll again in case images caused layout to shift
          })
        }
      }
      nav.addEventListener('touchstart', ignoreTouchScroll, {
        capture: true,
        passive: true,
      })
      nav.addEventListener('touchmove', ignoreTouchScroll, {
        capture: true,
        passive: true,
      })
      nav.addEventListener('touchend', ignoreTouchScroll, {
        capture: true,
        passive: true,
      })
      nav.querySelector('.nav-list').classList.add('is-loaded')
    } else if (e.target.classList.contains('nav-link')) {
      // when toggling a product in the sidebar
      navListQuery = (navItem = e.target.parentNode.parentNode).dataset
        .pinnedVersion
        ? '.nav-list[data-version="' + navItem.dataset.pinnedVersion + '"]'
        : '.nav-list[data-version]'
      var navItemState = navItem.classList.toggle('active')
      if ((navList = navItem.querySelector(navListQuery))) { navList.style.display = navItemState ? '' : 'none' }
      tippy.hideAll()
      window.analytics &&
      window.analytics.track('Toggled Nav', {
        url: e.target.innerText.trim(),
      })
    } else if (selected) {
      // when changing the selected version using the version selector
      navItem = nav.querySelector(
        '.nav-li[data-product="' + selected.product + '"]'
      )
      var navLists = navItem.querySelectorAll('.nav-list[data-product]')
      for (var i = 0, l = navLists.length; i < l; i++) {
        navLists[i].style.display =
          navLists[i].dataset.version === selected.version ? '' : 'none'
      }
      navItem.classList.add('active')
      tippy.hideAll()
    }
  }

  function toggleSubnav (e) {
    var navListParent = e.target.parentNode
    var navList = navListParent.lastChild
    if (navListParent.classList.contains('active')) {
      navList.style.display = 'none'
      navListParent.classList.remove('active')
    } else {
      navList.style.display = ''
      navListParent.classList.add('active')
    }
  }

  function scrollToActive (nav, thisList) {
    var focusElement =
      thisList.querySelector('.nav-link.active') || thisList.previousSibling
    var navRect = nav.getBoundingClientRect()
    var midpoint = (navRect.height - navRect.top) / 2
    var adjustment =
      focusElement.offsetTop + focusElement.offsetHeight / 2 - midpoint
    if (adjustment > 0) nav.scrollTop = adjustment
  }

  function setPinnedVersion (thisButton, pinned, navItem) {
    var analytics, pinnedVersion
    if ((pinnedVersion = pinned.version)) {
      localStorage.setItem('ms-docs-' + pinned.product, pinnedVersion)
      analytics = window.analytics
    } else if (
      !(pinnedVersion = localStorage.getItem('ms-docs-' + pinned.product))
    ) {
      return
    }
    (
      navItem || thisButton.parentNode.parentNode
    ).dataset.pinnedVersion = pinnedVersion
    thisButton.querySelector('.version-label').textContent = pinnedVersion
    analytics &&
    analytics.track('Version Pinned', {
      product: pinned.product,
      version: pinnedVersion,
    })
  }

  function initVersionSelector (versionButton, versionMenu, show) {
    tippy(versionButton, {
      content: versionMenu,
      role: 'menu',
      duration: [0, 150],
      flip: false,
      interactive: true,
      showOnInit: show,
      offset: '-60, 5',
      onHide: function (instance) {
        instance.popper.classList.remove('shown')
      },
      onHidden: function (instance) {
        unbindVersionEvents(instance.popper)
        instance.popper.classList.add('hide')
      },
      onShow: function (instance) {
        instance.popper.classList.remove('hide')
      },
      onShown: function (instance) {
        bindVersionEvents(instance.popper)
        instance.popper.classList.add('shown')
      },
      placement: 'bottom',
      theme: 'popover-versions',
      touchHold: true, // maps touch as click (for some reason)
      trigger: 'click',
      zIndex: 14, // same as z-nav-mobile
    })
    versionButton.addEventListener(
      'touchstart',
      function (e) {
        if (versionButton._tippy.state.isVisible) {
          versionButton._tippy.hide()
          cancelEvent(e)
        }
      },
      { capture: true, passive: true }
    )
  }

  function switchVersion (e) {
    var thisTippy = document.querySelector('.tippy-popper')._tippy
    var selected = {
      product: e.target.dataset.product,
      version: e.target.dataset.version,
    }
    setPinnedVersion(thisTippy.reference, selected)
    toggleNav(e, selected, getNav())
    thisTippy.hide()
    cancelEvent(e)
  }

  function bindVersionEvents (popover) {
    var versions = popover.querySelectorAll('.version')
    for (var i = 0, l = versions.length; i < l; i++) {
      versions[i].addEventListener('click', switchVersion)
      versions[i].addEventListener('touchend', cancelEvent)
    }
  }

  function unbindVersionEvents (popover) {
    var versions = popover.querySelectorAll('.version')
    for (var i = 0, l = versions.length; i < l; i++) {
      versions[i].removeEventListener('click', switchVersion)
      versions[i].removeEventListener('touchend', cancelEvent)
    }
  }

  function cancelEvent (e) {
    e.stopPropagation()
  }

  function ignoreTouchScroll (e) {
    if (e.type === 'touchstart') dragging = false
    else if (e.type === 'touchmove') dragging = true
    else if (e.type === 'touchend') {
      if (dragging) e.stopPropagation()
      dragging = false
    }
  }

  function getPage () {
    var pageProductMeta, head
    if (
      (pageProductMeta = (head = document.head).querySelector(
        'meta[name=page-component]'
      ))
    ) {
      return {
        product: pageProductMeta.getAttribute('content'),
        version: head
          .querySelector('meta[name=page-version]')
          .getAttribute('content'),
        url: head.querySelector('meta[name=page-url]').getAttribute('content'),
        uiRootPath: document.getElementById('site-script').dataset.uiRootPath,
      }
    }
  }

  function getNav () {
    return document.querySelector('nav.nav')
  }

  function isConnector (productName) {
    return (
      productName.endsWith('-connector') || productName.endsWith('-module')
    )
  }

  //   Check to see if the product is part of the rtf-cloud
  function isRTFCloud (productName) {
    return productName.endsWith('-rtfcloud')
  }

  function relativize (from, to) {
    if (!(from && to.charAt() === '/')) return to
    var hash = ''
    var hashIdx = to.indexOf('#')
    if (~hashIdx) {
      hash = to.substr(hashIdx)
      to = to.substr(0, hashIdx)
    }
    if (from === to) {
      return (
        hash ||
        (to.charAt(to.length - 1) === '/'
          ? './'
          : to.substr(to.lastIndexOf('/') + 1))
      )
    } else {
      return (
        (computeRelativePath(from.slice(0, from.lastIndexOf('/')), to) || '.') +
        (to.charAt(to.length - 1) === '/' ? '/' + hash : hash)
      )
    }
  }

  function computeRelativePath (from, to) {
    var fromParts = trimArray(from.split('/'))
    var toParts = trimArray(to.split('/'))
    for (
      var i = 0,
        l = Math.min(fromParts.length, toParts.length),
        sharedPathLength = l;
      i < l;
      i++
    ) {
      if (fromParts[i] !== toParts[i]) {
        sharedPathLength = i
        break
      }
    }
    var outputParts = []
    for (var remain = fromParts.length - sharedPathLength; remain > 0; remain--) { outputParts.push('..') }
    return outputParts.concat(toParts.slice(sharedPathLength)).join('/')
  }

  function trimArray (arr) {
    var start = 0
    var length = arr.length
    for (; start < length; start++) {
      if (arr[start]) break
    }
    if (start === length) return []
    for (var end = length; end > 0; end--) {
      if (arr[end - 1]) break
    }
    return arr.slice(start, end)
  }

  var nav, dragging
  var page = getPage()
  if (page) {
    buildNav((nav = getNav()), window.siteNavigationData || [], page, {
      active: [],
      current: [],
    })
    toggleNav(undefined, page, nav)
  }
})()

;(function () {
  'use strict'

  var doc = document.querySelector('.doc')
  var main = document.querySelector('.main')
  var sidebar = document.querySelector('.js-toc')
  if (!doc) {
    if (!sidebar) main.classList.add('no-sidebar')
    return
  }
  var menu
  var headings = find('.sect1 > h2[id]', doc)
  if (!headings.length) {
    if (sidebar) sidebar.removeChild(sidebar.querySelector('.js-toc'))
    return
  }
  var lastActiveFragment
  var links = {}

  var list = headings.reduce(function (accum, heading) {
    var link = toArray(heading.childNodes).reduce(function (target, child) {
      if (child.nodeName !== 'A') target.appendChild(child.cloneNode(true))
      return target
    }, document.createElement('a'))
    links[(link.href = '#' + heading.id)] = link
    var listItem = document.createElement('li')
    listItem.appendChild(link)
    accum.appendChild(listItem)
    return accum
  }, document.createElement('ol'))

  if (!(menu = sidebar && sidebar.querySelector('.toc-menu'))) {
    menu = document.createElement('div')
    menu.className = 'toc-menu'
  }

  menu.appendChild(list)

  if (sidebar) window.addEventListener('scroll', onScroll)

  var startOfContent = doc.querySelector('h1.page + *')
  if (startOfContent) {
    // generate list
    var options = headings.reduce(function (accum, heading) {
      var option = toArray(heading.childNodes).reduce(function (target, child) {
        if (child.nodeName !== 'A') target.appendChild(child.cloneNode(true))
        return target
      }, document.createElement('option'))
      option.value = '#' + heading.id
      accum.appendChild(option)
      return accum
    }, document.createElement('select'))

    var selectWrap = document.createElement('div')
    selectWrap.classList.add('select-wrapper')
    selectWrap.appendChild(options)

    // create jump to label
    var jumpTo = document.createElement('option')
    jumpTo.innerHTML = 'Jump to…'
    jumpTo.setAttribute('disabled', true)
    options.insertBefore(jumpTo, options.firstChild)
    options.className = 'toc toc-embedded select'

    // jump on change
    options.addEventListener('change', function (e) {
      var thisOptions = e.currentTarget.options
      window.location.hash = thisOptions[thisOptions.selectedIndex].value
    })

    // add to page
    doc.insertBefore(selectWrap, startOfContent)
  }

  function onScroll () {
    // NOTE equivalent to: doc.parentNode.getBoundingClientRect().top + window.pageYOffset
    var targetPosition = doc.parentNode.offsetTop
    var activeFragment
    headings.some(function (heading) {
      if (heading.getBoundingClientRect().top < targetPosition) {
        activeFragment = '#' + heading.id
      } else {
        return true
      }
    })
    if (activeFragment) {
      if (lastActiveFragment) {
        links[lastActiveFragment].classList.remove('active')
      }
      var activeLink = links[activeFragment]
      activeLink.classList.add('active')
      if (menu.scrollHeight > menu.offsetHeight) {
        menu.scrollTop = Math.max(0, activeLink.offsetTop + activeLink.offsetHeight - menu.offsetHeight)
      }
      lastActiveFragment = activeFragment
    } else if (lastActiveFragment) {
      links[lastActiveFragment].classList.remove('active')
      lastActiveFragment = undefined
    }
  }

  function find (selector, from) {
    return toArray((from || document).querySelectorAll(selector))
  }

  function toArray (collection) {
    return [].slice.call(collection)
  }
})()

;(function () {
  'use strict'

  var backdrop = document.querySelector('.modal-backdrop')
  var nav = document.querySelector('nav.nav')
  var navToggle = document.querySelector('.nav-toggle')

  function openNav (e) {
    document.body.addEventListener('click', closeNav)
    document.body.addEventListener('touchend', closeNav)
    cancelBubble(e)
    nav.classList.add('active')
    document.body.classList.add('no-scroll', 'mobile')
    backdrop.classList.add('show', 'mobile')
  }

  function closeNav (e) {
    document.body.removeEventListener('click', closeNav)
    document.body.removeEventListener('touchend', closeNav)
    nav.classList.remove('active')
    document.body.classList.remove('no-scroll', 'mobile')
    backdrop.classList.remove('show', 'mobile')
  }

  function cancelBubble (e) {
    e.stopPropagation()
    if (!e.target.href) e.preventDefault()
  }

  navToggle.addEventListener('click', openNav)
  navToggle.addEventListener('touchend', openNav)

  nav.addEventListener('click', cancelBubble)
  nav.addEventListener('touchend', cancelBubble)
})()

;(function () {
  'use strict'

  var analytics = window.analytics

  var jiraTriggers = document.querySelectorAll('.js-jira')
  if (jiraTriggers) {
    // open jira dialog
    window.ATL_JQ_PAGE_PROPS = {
      triggerFunction: function (showCollectorDialog) {
        var leaveFeedback = function (e) {
          e.preventDefault()
          analytics && analytics.track('Clicked Leave Feedback', { title: document.title, url: window.location.href })
        }
        for (var i = 0; i < jiraTriggers.length; i++) {
          jiraTriggers[i].addEventListener('click', function (e) {
            leaveFeedback(e)
            showCollectorDialog()
          })
          jiraTriggers[i].addEventListener('touchend', function (e) {
            leaveFeedback(e)
            showCollectorDialog()
          })
        }
      },
      fieldValues: {
        description: 'URL: ' + window.location.href,
      },
    }
  }

  if (!analytics) return

  // saying thanks
  var thanksSection = document.querySelector('.js-thanks-section')
  var thanksYesTrigger = thanksSection.querySelector('.js-thanks-yes')
  var thanksNoTrigger = thanksSection.querySelector('.js-thanks-no')
  var sayThanks = function () {
    thanksSection.classList.add('flip')
  }
  var trackHelpful = function () {
    sayThanks()
    analytics && analytics.track('Clicked Helpful Yes', { title: document.title, url: window.location.href })
  }
  var trackNotHelpful = function () {
    sayThanks()
    analytics && analytics.track('Clicked Helpful No', { title: document.title, url: window.location.href })
  }

  thanksYesTrigger.addEventListener('click', trackHelpful)
  thanksYesTrigger.addEventListener('touchend', trackHelpful)
  thanksNoTrigger.addEventListener('click', trackNotHelpful)
  thanksNoTrigger.addEventListener('touchend', trackNotHelpful)
})()

;(function () {
  'use strict'

  var analytics = window.analytics

  var gitHubLinks = document.querySelectorAll('.js-github')
  var trackGitHub = function () {
    analytics && analytics.track('Clicked GitHub Link', { url: window.location.href })
  }

  for (var i = 0; i < gitHubLinks.length; i++) {
    gitHubLinks[i].addEventListener('click', trackGitHub)
    gitHubLinks[i].addEventListener('touchend', trackGitHub)
  }
})()

;(function () {
  'use strict'

  document.addEventListener('DOMContentLoaded', function () {
    var gdprEl = document.querySelector('.js-gdpr')
    var gdprClose = document.querySelector('.js-gdpr-close')
    if (!(gdprEl && gdprClose)) return
    var gdprFlag = localStorage.getItem('GDPR')

    function closeGDPR () {
      localStorage.setItem('GDPR', 'off')
      gdprEl.classList.remove('show')
    }

    if (!gdprFlag) gdprEl.classList.add('show')

    gdprClose.addEventListener('click', closeGDPR)
    gdprClose.addEventListener('touchend', closeGDPR)
  })
})()

;(function () {
  'use strict'

  // connector level popover
  var connectorTierTrigger = document.querySelector('.js-connector-level-trigger')
  /* eslint-disable max-len */
  var communityTierMsg =
    '<p>MuleSoft or members of the community write and maintain Community Connectors.<p>Contact the partner directly for more information. You do not need any special account or license to use a Community connector.'
  var certifiedTierMsg =
    '<p>MuleSoft Certified connectors are developed by MuleSoft’s partners and developer community and are reviewed and certified by MuleSoft.<p>For support, customers should contact the MuleSoft partner that created the connector.'
  var selectTierMsg =
    '<p>Connectors in the Select level are maintained by MuleSoft.<p>Connectors included in the open source Mule distribution can be used by everyone, however support is only included in an Anypoint Platform subscription.'
  var premiumTierMsg =
    '<p>MuleSoft maintains Premium connectors. You must purchase Premium connectors as add-ons to your subscription.'
  /* eslint-enable max-len */

  if (connectorTierTrigger) {
    var msg
    var level = connectorTierTrigger.getAttribute('data-level')
    if (level) {
      switch (level.toLowerCase()) {
        case 'community':
          msg = communityTierMsg
          break
        case 'certified':
          msg = certifiedTierMsg
          break
        case 'select':
          msg = selectTierMsg
          break
        case 'premium':
          msg = premiumTierMsg
          break
      }
    }

    if (msg) {
      tippy(connectorTierTrigger, {
        boundary: 'window',
        content: msg,
        duration: [0, 150],
        flip: false,
        maxWidth: 240,
        offset: '0, 10',
        placement: 'bottom-end',
        role: 'menu',
        theme: 'popover popover-level',
        touchHold: true, // maps touch as click (for some reason)
        zIndex: 14, // same as z-nav-mobile
        onHide: function (instance) {
          instance.popper.classList.remove('shown')
        },
        onHidden: function (instance) {
          instance.popper.classList.add('hide')
        },
        onShow: function (instance) {
          instance.popper.classList.remove('hide')
        },
        onShown: function (instance) {
          instance.popper.classList.add('shown')
        },
      })
    }
  }
})()
